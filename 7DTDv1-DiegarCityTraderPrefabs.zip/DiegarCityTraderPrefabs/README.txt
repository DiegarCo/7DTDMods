Hello. This mod includes 4 custom prefabs designed in 
7 Days to Die v1.1:

	Downtown Trader Jen (diegar_downtown_traderJen)
	Downtown Trader Joel (diegar_downtown_traderJoel)
	Downtown Trader Hugh (diegar_downtown_traderHugh)
	Downtown Trader Bob (diegar_downtown_traderBob)

I don't like Rekt, so skipped him. Let me know if you 
really want it, and I'll create one for him too. 
Will only generate in cities with downtown zones.

Unzip DiegarCityTraderPrefabs folder to your 7dtd /Mods 
folder prior to generating a new map.

There is an optional config file in Config folder with instructions 
to set Downtown Traders to 24x7 hours, and restocking daily.

If you like my work and want to toss me a couple bucks:
https://www.paypal.com/donate/?hosted_button_id=STP3YU8J2BV68