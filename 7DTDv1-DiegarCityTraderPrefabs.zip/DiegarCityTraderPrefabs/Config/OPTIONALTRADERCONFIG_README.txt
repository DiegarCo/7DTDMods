<!-- 

******************************************************************
*** Optional config. If you want city traders to be open 24x7, ***
*** and restock daily, rename this file to 'traders.xml'        ***
******************************************************************

-->

<Diegar>
	<config>

		<set xpath="/traders/trader_info[@id='9']/@reset_interval">1</set>
		<set xpath="/traders/trader_info[@id='9']/@open_time">0:00</set>
		<set xpath="/traders/trader_info[@id='9']/@close_time">0:00</set>
		
	</config>
</Diegar>