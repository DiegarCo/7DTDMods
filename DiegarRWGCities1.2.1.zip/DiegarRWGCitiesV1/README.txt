Thank you for choosing DiegarCo mods! Please read each section
before intalling your new server. This is very much a work in 
progress.

- Must be placed in Mods folder before generating your world

- In serverconfig.xml, Gameworld must be set to "RWG". 
  WorldGenSize needs to be 6144, 8192, or 10240. Haven't done
  must testing with Small and Medium world gens. Mostly focused
  Large 10240 worlds. 

- I've only ever generated from startdedicated.bat

- While world is generating, it will pause for a few minutes. 
  Once it starts outputting logs again, it will show you how
  many cities are in each biome like this:

	INF TownPlanner forest has 7 townships, citybig 1, city 2, roadside 4
	INF TownPlanner burntForest has 6 townships, wasteland_city 1, bforest_town 1, bforest_countrytown 1, roadside 3
	INF TownPlanner desert has 4 townships, citybig 1, roadside 3
	INF TownPlanner snow has 5 townships, wasteland_city 1, roadside 4
	INF TownPlanner wasteland has 3 townships, citybig 2, roadside 1

  If while generating a large map, you don't see at least one 
  wasteland_city or citybig in each of the five biomes, close
  the server window and start over. None of the generation progress
  is saved at this point. Citybig is the largest!

- Thanks again and happy hunting!