Hello. This mod includes 5 custom prefabs designed in 
7 Days to Die v3.0:

	Downtown Trader Jen (diegar_downtown_traderJen)
	Downtown Trader Joel (diegar_downtown_traderJoel)
	Downtown Trader Hugh (diegar_downtown_traderHugh)
	Downtown Trader Bob (diegar_downtown_traderBob)
	Downtown Trader Rekt (diegar_downtown_TraderRekt)

I don't like Rekt, so skipped him the last few years, but I broke down and finally added him. He's grown on me...

Will only generate in cities with downtown tiles.

Unzip DiegarDowntownTraders folder to your 7dtd /Mods 
folder prior to generating a new map.

If you like my work and want to toss me a couple bucks:
https://www.paypal.com/donate/?hosted_button_id=STP3YU8J2BV68