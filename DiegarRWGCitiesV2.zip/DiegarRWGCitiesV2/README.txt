Thank you for choosing DiegarCo mods! 

Please visit 7daystodiemods.com for detailed installation instructions where you found this mod. 
Please give it a heart and share any feedback, and if you feel like chipping in a few bucks, please
visit https://www.paypal.com/donate/?hosted_button_id=STP3YU8J2BV68

- Thanks again and happy hunting!