Thank you for choosing DiegarCo mods! Please read each section
before intalling your new server. This is very much a work in 
progress.

- Must be placed in Mods folder before generating your world

- In serverconfig.xml, Gameworld must be set to "RWG". 
  WorldGenSize needs to be 6144, 8192, or 10240. Haven't done
  must testing with Small and Medium world gens. Mostly focused
  Large 10240 worlds. 

- I've only ever generated from startdedicated.bat

- While world is generating, it will pause for a few minutes. 
  Once it starts outputting logs again, it will show you how
  many cities are in each biome like this:

	2026-06-30T12:04:01 1087.692 INF TownPlanner Plan 16 in 1082.714
	2026-06-30T12:04:01 1087.693 INF TownPlanner forest has 3 townships, citybig 3
	2026-06-30T12:04:01 1087.693 INF TownPlanner burntForest has 3 townships, citybig 3
	2026-06-30T12:04:01 1087.693 INF TownPlanner desert has 2 townships, citybig 2
	2026-06-30T12:04:01 1087.693 INF TownPlanner snow has 4 townships, citybig 4
	2026-06-30T12:04:01 1087.693 INF TownPlanner wasteland has 4 townships, citybig 4

  If while generating a large map, you don't see at least one 
  wasteland_city or citybig in each of the five biomes, close
  the server window and start over. None of the generation progress
  is saved at this point. Citybig is the largest!

- Thanks again and happy hunting!